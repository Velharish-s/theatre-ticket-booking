package Ticket;

import java.util.HashMap;

public class Movies {
	public static  HashMap<String,Theatre> hm4=new HashMap<>();
	{
		hm4.put("movie1", new Theatre());
		hm4.put("movie2", new Theatre());
		hm4.put("movie3", new Theatre());
	}
}
