package Ticket;

import java.util.HashMap;

public class Date {
	HashMap<String,Shows> hm2=new HashMap<>();
	{
		hm2.put("09-04-2025",new Shows());
		hm2.put("10-04-2025", new Shows());
		hm2.put("11-04-2025", new Shows());
		hm2.put("12-04-2025", new Shows());
		hm2.put("13-04-2025", new Shows());
	}
}
