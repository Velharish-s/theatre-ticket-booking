package Ticket;
import java.util.*;
public class User {
	ArrayList<String> tickets=new ArrayList<>();
	{
		System.out.println("Finished!!");
	}
}
