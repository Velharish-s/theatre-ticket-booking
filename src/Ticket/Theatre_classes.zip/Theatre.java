package Ticket;
import java.util.*;
public class Theatre {
	HashMap<String,Date> hm3=new HashMap<>();
	{
		hm3.put("pvr(erode)",new Date());
		hm3.put("pvr(chennai)",new Date());
		hm3.put("pvr(salem)",new Date());
	}
}
